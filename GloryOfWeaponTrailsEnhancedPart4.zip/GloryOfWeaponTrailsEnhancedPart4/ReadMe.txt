Hello,

This is the readme for Part 4 of the source files for the Glory of Weapon Trails mod for Conan Exiles, Enhanced version.

DESCRIPTION OF CONTENTS

This fourth part only contains animation folders for particular weapon classes. Specifically, these are:

* One-Handed Axe
* Two-Handed Axe
* Shield
* Throwing Axe
* Katana (known as 'Weeb')


INSTALLATION

Please add the animation subfolders included in this package into the Animations folder in Part 1. Once all five parts have been combined, the complete GloryOfWeaponTrails folder can be placed into the DevKit's mod directory, likely located here:

\CEUE5Devkit\UE4\Content\Mods

The mod should then only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations.


Please refer to Part 1's readme for more complete details on the mod.