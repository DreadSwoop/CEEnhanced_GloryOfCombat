Hello,

This is the readme for the source files for the Glory of Weapon Trails mod for Conan Exiles, Enhanced version.



!!!!! PLEASE CHECK INSTALLATION SECTION FOR INSTRUCTIONS ON COMBINING THE FIVE PARTS OF THE MOD !!!!!



DESCRIPTION OF CONTENTS

You may notice that while the main folder's name is 'GloryOfWeaponTrails', many data tables bear an 'ASO' prefix designation. Attack System Overhaul was the name I used while creating the main mod in April - May 2020 before I had come up with the name 'Glory of Combat'. The main mod and this version share most assets, and since essentially no one (except you now) would see the table names there wasn't much point to rename everything.

Most of the mod's assets are animation files and data tables. The animations can be found in the Animations folder, where I've subdivided them into their specific weapon classes. Some animations, especially the segments, are used by more than one class. A few of these animations had been removed from the DevKit years ago, making them otherwise unobtainable. Do take note that, for many animations in the editor, the character reference is a naked lady; that's not my fault. Try and make sure the wrong people aren't exposed to them.

(NOTE: This first part only contains the animation folders for the following weapon classes:

* One-Handed Sword
* Two-Handed Sword
* Unarmed

The other animation folders are contained within Parts 2 through 5.)

The Sounds folder contains a small number of adjusted sound effect files for weapon swings or various Bow sounds. There is a small data table and control table included here as well to adjust the sound profiles utilized by certain weapons.

The Staggers folder holds three custom knockback blueprints that were once made for certain attacks. I believe only the FlurryPull effect is still currently in use.

The main mod folder has a large array of tables containing combat data, with most tables themed to one specific weapon class, excepting tools, mounted attacks, and miscellaneous bits. It was done this was for easy access and organization, as having one gigantic table would be cumbersome when making certain changes. The Workbench table is intended for testing potential changes without having to adjust the modded tables directly. Here there is also a data table and control table for merging into WeaponUseTable, in the past to allow for the Bow hop to function but now just to overwrite the equip animations.

The ModController is used to perform table mergers to add the modded combat data into DT_ComboRules, along with the WeaponUse and WeaponMaterial tables. Each of the smaller tables is merged individually, over 20 times across the whole set. Note that I did also remove some sprint attack IDs from use, which can be reversed by simply removing that block from the chain.

Aside from the Weapon Trails version having a couple more animations to account for the trails, the only difference between this mod and the main version are the weapon trails assigned to each animation.


INSTALLATION

I had to split the mod into 5 pieces because the overall size was too large to upload to GitHub in one block. You must download these pieces and then reassemble them together if you want the mod to function correctly in the DevKit.

The process should be as simple as copyings the animation subfolders (for example 1hAxe, 2hSpear) in Parts 2, 3, 4, and 5 into the Animations folder in Part 1. The full folder paths has been included in Parts 2 through 5, so you could just combine those GloryOfWeaponTrail folders into the one included here. Ensure they are combined properly, and do this BEFORE sticking the mod in the DevKit.

To add the mod into your DevKit, copy the fully-combined 'GloryOfWeaponTrails' folder into the mod directory. From the main DevKit folder, the path will very likely be:

\CEUE5Devkit\UE4\Content\Mods

The mod should then only need to be re-cooked (rebuilt) in the DevKit to become functional once again, unless Inflexion, Funcom, or whoever else decide to do some major renovations.


MISCELLANEOUS

If you're interested in testing the mod in advance of publishing or simply for your own use, you can copy the cooked pak file to the Mods folder in your game files and then enable in the main menu.

The pak file uses the name of the GloryOfWeaponTrails folder in the DevKit and not the mod name in the DevKit's Info Panel. Changing the name of the mod can be done in a few different ways, but I would strongly recommend NOT doing so unless it's important to you. Most methods will result in all the references in the mod breaking, which would require you to piece every animation back together like a puzzle, which speaking from personal experience is not fun. There is a method that can do so without breaking everything, but I'm not going to detail the process here, you can find that on your own. I would however recommend making a backup beforehand.


CONCLUSION

Hopefully that covers the basics, I look forward to seeing your version (don't screw it up)! If you decide to re-upload, let me know and I'll provide a link to your mod page.

Thanks for reading,

Dread Swoop
